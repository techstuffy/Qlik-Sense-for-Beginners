Sample spreadsheets for incremental qvd example:

inc_qvd.xls
inc_qvd_add_modified.xls
inc_qvd_append.xls
inc_qvd_deleted.xls
inc_qvd_inital_load - Copy.xls
inc_qvd_inital_load.xls
inc_qvd_modified_user.xls

full qvd incremental load.txt

buffer example.txt 