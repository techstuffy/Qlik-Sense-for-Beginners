﻿define( [
],
function ( ) {

	return {
		paint: function ($element) {
			$element.html( "<iframe src='http://www.techstuffy.com' width='100%' height='100%'>test</iframe>" );
		}
	};

} );
